<form action="">
    <input type="text">
    <input type="button">
</form>
<?php
echo "asdf <br>";
echo basename("c:/test");
?>