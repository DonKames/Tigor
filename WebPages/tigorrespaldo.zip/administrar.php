<?php
require_once 'vendor/autoload.php';

use Firebase\JWT\JWT;

if (isset($_COOKIE['token'])) {
  $token = $_COOKIE['token'];
  echo json_encode($token);
  try {
    $data = JWT::decode($token, 'R1O2G3I4T5', array('HS256'));
  } catch (Exception $e) {
    header('Location: login.html');
  }
  //echo json_encode($data);
}
?>
<!DOCTYPE html>
<html class="h-100" lang="es">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TIGOR Administracion</title>
  <!--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">-->
  <link rel="stylesheet" href="sass/custom.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="scripts/funcionesGenerales.js"></script>
  <script src="scripts/funcionesCliente.js"></script>
  <script src="scripts/funcionesProveedor.js"></script>
  <script src="scripts/funcionesCategoria.js"></script>
  <script src="scripts/funcionesProduct.js"></script>
  <script src="scripts/funcionesSession.js"></script>
  <script src="scripts/funcionesCotizacion.js"></script>
  <script src="scripts/funcionesComuna.js"></script>
  <script src="scripts/funcionesContact.js"></script>
  <script src="node_modules/html2pdf.js/dist/html2pdf.bundle.min.js"></script>
  <script>
    //window.onload = recuperarClientes();
    //window.onload = recuperarProveedores();
    window.onload = VerificarSession();
    //window.onload = recuperarCategorias("administrar");
    //window.onload = recuperarProducts_Administrar();
    window.onload = recuperarCategorias("administrar");
  </script>
</head>

<body class="d-flex flex-column h-100">


  <!--HEADER-->
  <header>
    <nav class="navbar navbar-expand navbar-light bg-secondary">
      <div class="container">
        <a class="navbar-brand" href="index.html">CyD Torres Igor</a>
        <!-- El NAVBAR y sus opciones -->
        <ul class="navbar-nav">
          <li class="btn-group">
            <a type="button" class="btn btn-secondary" href="productos.html">Nuestros Productos</a>
            <button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false">
              <span class="visually-hidden">Toggle Dropdown</span>
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">CATEGORIAS</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="#">Categoria 1</a></li>
              <li><a class="dropdown-item" href="#">Categoria 2</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contactanos.html">Contactanos</a>
          </li>
          <a href="cotizar.html"><button class="btn btn-outline-dark" type="button">Cotiza</button></a>
        </ul>
      </div>
    </nav>
    <div style="height: 3px; background-color: red;"></div>
  </header>
  <!--Cuerpo-->
  <div class="container">
    <!--Titulo Pagina-->
    <div class="row mt-2 mb-3">
      <div class="col-1"></div>
      <div class="col-10">
        <h1 class="text-center">Administracion</h1>
      </div>
      <div class="col-1">
        <button class="btn btn-danger" type="button" onclick="CerrarSesion();">Cerrar Sesion</button>
      </div>
    </div>

    <!--Card Principal-->
    <div class="card mb-3">
      <!--Card Header Nav TAB-->
      <div class="card-header">
        <ul class="nav nav-tabs nav-fill" id="AdminTab" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link active" id="tabClientes" data-bs-toggle="tab" data-bs-target="#clientesConte" type="button" role="tab" aria-controls="tabClientes" aria-selected="true"><strong>Clientes</strong></button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="tabProveedores" data-bs-toggle="tab" data-bs-target="#proveedoresConte" type="button" role="tab" aria-controls="tabProveedores" aria-selected="false"><strong>Proveedores</strong></button>
          </li>
          <!--<li class="nav-item" role="presentation">
            <button class="nav-link" id="tabCategorias" data-bs-toggle="tab" data-bs-target="#categoriasConte" type="button" role="tab" aria-controls="tabCategorias" aria-selected="false"><strong>Categorías</strong></button>
          </li>-->
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="tabProducts" data-bs-toggle="tab" data-bs-target="#productsConte" type="button" role="tab" aria-controls="tabProducts" aria-selected="false"><strong>Productos</strong></button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="tabCotizaciones" data-bs-toggle="tab" data-bs-target="#cotizacionesConte" type="button" role="tab" aria-controls="tabCotizaciones" aria-selected="false" onclick="getCotizaciones()"><strong>Cotizaciones</strong></button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="tabContacto" data-bs-toggle="tab" data-bs-target="#contactoConte" type="button" role="tab" aria-controls="tabContacto" aria-selected="false" onclick="getContacts()"><strong>Contacto</strong></button>
          </li>
        </ul>
      </div>

      <!--Card Body-->
      <div class="card-body">
        <div class="tab-content" id="AdminTabConte">

          <!--Accordion Clientes-->
          <div class="tab-pane fade show active" id="clientesConte" role="tabpanel" aria-labelledby="tabClientes">
            <div class="accordion" id="accordionClientes">
              <!--Accordion opcion 1 Agregar Cliente-->
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerAgregarCliente">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAgregarCliente" aria-expanded="true" aria-controls="collapseAgregarCliente" id="btnAccordionAgregarCliente"><strong>Agregar Cliente</strong></button>
                </h2>
                <div id="collapseAgregarCliente" class="accordion-collapse collapse show" aria-labelledby="headerAgregarCliente" data-bs-parent="#accordionClientes">
                  <div class="accordion-body">
                    <form action="php/CrudCliente.php" method="post">
                      <div class="row">
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="text" class="form-control" id="floatRutCliente" placeholder="rutCliente" name="rutCliente">
                          <label for="floatRutCliente" class="ms-3">Rut</label>
                          <div class="form-text">Sin punto ni guión.</div>
                        </div>
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="text" class="form-control" id="floatNombreCliente" placeholder="nombreCliente" name="nombreCliente" required>
                          <label for="floatNombreCliente" class="ms-3">Nombre</label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="text" class="form-control" id="floatDireccionCliente" placeholder="direccionCliente" name="direccionCliente" required>
                          <label for="floatDireccionCliente" class="ms-3">Dirección</label>
                        </div>
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input class="form-control" list="datalistComunasCliente" id="floatSelectComunaCliente" placeholder="Escriba para buscar..." name="comunaCliente">
                          <datalist id="datalistComunasCliente">
                          </datalist>
                          <script>
                            window.onload = getComunas();
                          </script>
                          <label for="floatSelectComunaCliente" class="ms-3">Comuna</label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="email" class="form-control" id="floatEmailCliente" placeholder="emailCliente" name="emailCliente" required>
                          <label for="floatEmailCliente" class="ms-3">Correo Electronico</label>
                        </div>
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="text" class="form-control" id="floatTelefonoCliente" placeholder="numeroCliente" name="telefonoCliente" required>
                          <label for="floatTelefonoCliente" class="ms-3">Teléfono</label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="d-flex justify-content-end">
                          <button type="button" class="btn btn-primary btn-lg" name="btnForm" value="agregarCliente" id="btnAgregarCliente" onclick="postClient()">
                            Agregar Cliente
                          </button>
                          <button type="reset" class="btn btn-danger btn-lg me-5" id="btnResetCliente" onclick="resetCliente('Cliente')" hidden>
                            Cancelar
                          </button>
                          <button type="submit" class="btn btn-primary btn-lg" name="btnForm" value="modificarCliente" id="btnModificarCliente" hidden>
                            Modificar Cliente
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <!--Accordion opcion 2 Mostrar Clientes-->
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerMostrarClientes">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMostrarClientes" aria-expanded="false" aria-controls="collapseMostrarClientes" id="btnAccordionMostrarClientes" onclick="recuperarClientes()"><strong>Mostrar Clientes</strong></button>
                </h2>
                <div id="collapseMostrarClientes" class="accordion-collapse collapse" aria-labelledby="headerMostrarClientes" data-bs-parent="#accordionClientes">
                  <div class="accordion-body">
                    <div class="table-responsive">
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Rut</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Dirección</th>
                            <th scope="col">Comuna</th>
                            <th scope="col">E-Mail</th>
                            <th scope="col">Telefono</th>
                            <th scope="col"></th>
                          </tr>
                        </thead>

                        <tbody id="cuerpoTablaMostrarClientes">
                          <tr>
                            <th scope="row">1</th>
                            <td>Talleres Metalurgicos Chile S.A.</td>
                            <td>93.160.000-1</td>
                            <td>Correa Errazuriz</td>
                            <td>Aguirre Cerda</td>
                            <td>contacto@talleresmetalurgicos.cl</td>
                            <td>+56912341234</td>
                            <td>
                              <img src="imgs/editar.png" alt="" style="height:30px; width: 30px;" onclick="">
                              <a href=""><img src="imgs/borrar.png" alt="" style="height:30px; width: 30px;"></a>
                            </td>
                          </tr>
                          <tr>
                            <th scope="row">2</th>
                            <td>Talleres Metalurgicos Chile S.A.</td>
                            <td>93.160.000-1</td>
                            <td>Correa Errazuriz</td>
                            <td>Aguirre Cerda</td>
                            <td>contacto@talleresmetalurgicos.cl</td>
                            <td>+56912341234</td>
                          </tr>
                        </tbody>

                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!--Accordion Proveedores-->
          <div class="tab-pane fade" id="proveedoresConte" role="tabpanel" aria-labelledby="tabProveedores">
            <div class="accordion" id="accordionProveedores">
              <!--Accordion opcion 1 Agregar Proveedor-->
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerAgregarProveedor">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAgregarProveedor" aria-expanded="true" aria-controls="collapseAgregarProveedor" id="btnAccordionAgregarProveedor"><strong>Agregar
                      Proveedor</strong></button>
                </h2>
                <div id="collapseAgregarProveedor" class="accordion-collapse collapse show" aria-labelledby="headerMostrarProveedor" data-bs-parent="#accordionProveedores">
                  <div class="accordion-body">
                    <form action="php/CrudProveedor.php" method="post">
                      <div class="row">
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="text" class="form-control" id="floatRutProveedor" placeholder="rutProveedor" name="rutProveedor">
                          <label for="floatRutProveedor" class="ms-3">Rut</label>
                          <div class="form-text">Sin punto ni guión.</div>
                        </div>
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="text" class="form-control" id="floatNombreProveedor" placeholder="nombreProveedor" name="nombreProveedor">
                          <label for="floatNombreProveedor" class="ms-3">Nombre</label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="text" class="form-control" id="floatDireccionProveedor" placeholder="direccionProveedor" name="direccionProveedor">
                          <label for="floatDireccionProveedor" class="ms-3">Dirección</label>
                        </div>
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input class="form-control" list="datalistComunasCliente" name="comunaProveedor" id="floatSelectComunaProveedor" placeholder="Escriba para buscar...">
                          <label for="floatSelectComunaProveedor" class="ms-3">Comuna</label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="email" class="form-control" id="floatEmailProveedor" placeholder="emailProveedor" name="emailProveedor" required>
                          <label for="floatEmailProveedor" class="ms-3">Correo Electronico</label>
                        </div>
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="text" class="form-control" id="floatTelefonoProveedor" maxlength="15" placeholder="telefonoProveedor" name="telefonoProveedor" required>
                          <label for="floatTelefonoProveedor" class="ms-3">Teléfono</label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="d-flex justify-content-end">
                          <button type="button" class="btn btn-primary btn-lg" name="btnForm" value="agregarProveedor" id="btnAgregarProveedor" onclick="postProveedor()">
                            Agregar Cliente
                          </button>
                          <button type="reset" class="btn btn-danger btn-lg me-5" id="btnResetProveedor" onclick="resetCliente('Proveedor')" hidden>
                            Cancelar
                          </button>
                          <button type="submit" class="btn btn-primary btn-lg" name="btnForm" value="modificarProveedor" id="btnModificarProveedor" onclick="" hidden>
                            Modificar Cliente
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <!--Accordion opcion 2 Mostrar Proveedores-->
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerMostrarProveedores">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMostrarProveedors" aria-expanded="false" aria-controls="collapseMostrarProveedors" id="btnAccordionMostrarProveedors" onclick="recuperarProveedores()"><strong>Mostrar Proveedores</strong></button>
                </h2>
                <div id="collapseMostrarProveedors" class="accordion-collapse collapse" aria-labelledby="headerMostrarProveedores" data-bs-parent="#accordionProveedores">
                  <div class="accordion-body">
                    <div class="table-responsive">
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Rut</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Dirección</th>
                            <th scope="col">Comuna</th>
                            <th scope="col">E-Mail</th>
                            <th scope="col">Telefono</th>
                            <th scope="col"></th>
                          </tr>
                        </thead>
                        <tbody id="cuerpoTablaMostrarProveedores">
                          <tr>
                            <th scope="row">1</th>
                            <td>Talleres Metalurgicos Chile S.A.</td>
                            <td>93.160.000-1</td>
                            <td>Correa Errazuriz</td>
                            <td>Aguirre Cerda</td>
                            <td>contacto@talleresmetalurgicos.cl</td>
                            <td>+56912341234</td>
                          </tr>
                          <tr>
                            <th scope="row">2</th>
                            <td>Talleres Metalurgicos Chile S.A.</td>
                            <td>93.160.000-1</td>
                            <td>Correa Errazuriz</td>
                            <td>Aguirre Cerda</td>
                            <td>contacto@talleresmetalurgicos.cl</td>
                            <td>+56912341234</td>
                          </tr>
                        </tbody>

                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!--Accordion Categorias-->
          <!--<div class="tab-pane fade" id="categoriasConte" role="tabpanel" aria-labelledby="tabCategorias">
            <div class="accordion" id="accordionCategorias">
              Accordion opcion 1 Agregar Categoria
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerAgregarCategoria">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAgregarCategoria" aria-expanded="true" aria-controls="collapseAgregarCategoria" id="btnAccordionAgregarCategoria"><strong>Agregar
                      Categoria</strong></button>
                </h2>
                <div id="collapseAgregarCategoria" class="accordion-collapse collapse show" aria-labelledby="headerMostrarCategoria" data-bs-parent="#accordionCategorias">
                  <div class="accordion-body">
                    <form action="php/CrudCategoria.php" method="post">
                      <div class="row">
                        <div class="form-floating col-12 col-md-6 mb-3" hidden>
                          <input type="text" class="form-control" id="floatIdCategoria" placeholder="idCategoria" name="idCategoria">
                          <label for="floatIdCategoria" class="ms-3">Id</label>
                        </div>
                        <div class="form-floating col-12 col-md-6 mb-3">
                          <input type="text" class="form-control" id="floatNombreCategoria" placeholder="nombreCategoria" name="nombreCategoria">
                          <label for="floatNombreCategoria" class="ms-3">Nombre</label>
                        </div>
                        <div class="d-flex justify-content-end col-12 col-md-6 mb-3">
                          <button type="button" class="btn btn-primary btn-lg flex-md-fill" name="btnForm" value="agregarCategoria" id="btnAgregarCategoria" onclick="postCategoria()">
                            Agregar Categoria
                          </button>
                          <button type="reset" class="btn btn-danger btn-lg me-5" id="btnResetCategoria" onclick="resetCliente('Categoria')" hidden>
                            Cancelar
                          </button>
                          <button type="submit" class="btn btn-primary btn-lg" name="btnForm" value="modificarCategoria" id="btnModificarCategoria" onclick="" hidden>
                            Modificar Cliente
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              Accordion opcion 2 Mostrar Categoria
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerMostrarCategoria">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMostrarCategorias" aria-expanded="false" aria-controls="collapseMostrarCategorias" id="btnAccordionMostrarCategorias" onclick="recuperarCategorias('administrar')"><strong>Mostrar Categoria</strong></button>
                </h2>
                <div id="collapseMostrarCategorias" class="accordion-collapse collapse" aria-labelledby="headerMostrarCategoria" data-bs-parent="#accordionCategorias">
                  <div class="accordion-body">
                    <div class="table-responsive">
                      <table class="table table-striped placeholder-glow">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">ID</th>
                            <th scope="col">Nombre</th>
                            <th scope="col"></th>
                          </tr>
                        </thead>
                        <tbody id="cuerpoTablaMostrarCategorias">
                          <tr>
                            <th scope="row" class="placeholder">1</th>
                            <td class="placeholder">Cargando su TABLA</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>-->

          <!--Accordion Productos-->
          <div class="tab-pane fade" id="productsConte" role="tabpanel" aria-labelledby="tabProducts">
            <div class="accordion" id="accordionProducts">

              <!--Accordion opcion 1 Agregar Productos-->
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerAgregarProduct">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAgregarProduct" aria-expanded="true" aria-controls="collapseAgregarProduct" id="btnAccordionAgregarProduct"><strong>Agregar Producto</strong></button>
                </h2>
                <div id="collapseAgregarProduct" class="accordion-collapse collapse show" aria-labelledby="headerAgregarProduct" data-bs-parent="#accordionProducts">
                  <div class="accordion-body">
                    <form action="php/CrudProduct.php" method="post" enctype="multipart/form-data">
                      <div class="row">
                        <div class="col-12 col-md-4 mb-3" id="imgProdZone">
                          <img src="imgs/ProntoDisponibleAmarillo.jpg" alt="" class="img-fluid" id="imgProd">
                        </div>
                        <div class="col-12 col-md-8">
                          <div class="mb-3">
                            <label for="subirArchivo" class="form-label">Seleccione la Imagen del Producto</label>
                            <input class="form-control" type="file" id="subirArchivo" name="imgProduct" onchange="previewImg()">
                          </div>
                          <div class="form-floating col-12 mb-3">
                            <input type="text" class="form-control" id="floatCodigoProduct" placeholder="rutProduct" name="codigoProduct">
                            <label for="floatRutProduct" class="ms-3">Codigo</label>
                          </div>
                          <div class="form-floating col-12 mb-3">
                            <input type="text" class="form-control" id="floatNombreProduct" placeholder="nombreProduct" name="nombreProduct">
                            <label for="floatNombreProduct" class="ms-3">Nombre</label>
                          </div>
                          <div class="form-floating col-12 mb-3">
                            <select class="form-select" id="floatSelectCategoriaProduct" aria-label="labelSelect" name="categoriaProduct">
                            </select>
                            <label for="floatSelectCategoriaProduct" class="ms-3">Categoria</label>
                          </div>
                        </div>
                        <div class="form-floating col-12 mb-3">
                          <textarea class="form-control" placeholder="Descripción del Product" id="floatDescripcionProduct" rows="50" style="height: 10em;" name="descripcionProduct"></textarea>
                          <label for="floatdescripcionProduct" class="ms-3">Descripción del Producto</label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="d-flex justify-content-end">
                          <button type="button" class="btn btn-primary btn-lg" name="btnForm" value="agregarProduct" id="btnAgregarProduct" onclick="postProduct()">
                            Agregar Producto
                          </button>
                          <button type="reset" class="btn btn-danger btn-lg me-5" id="btnResetProduct" onclick="resetCliente('Product')" hidden>
                            Cancelar
                          </button>
                          <button type="submit" class="btn btn-primary btn-lg" name="btnForm" value="modificarProduct" id="btnModificarProduct" hidden>
                            Modificar Cliente
                          </button>
                        </div>
                      </div>
                    </form>
                    <script>
                      function readFile(input) {
                        if (input.files && input.files[0]) {
                          let reader = new FileReader();
                          reader.onload = function(e) {
                            let filePreview = document.createElement('img');
                            filePreview.id = 'imgProd';
                            //e.target.result contents the base64 data from the image uploaded
                            filePreview.setAttribute('class', 'img-fluid');
                            filePreview.src = e.target.result;
                            console.log(e.target.result);
                            let previewZone = document.getElementById('imgProdZone');
                            let imgProd = document.getElementById('imgProd');
                            previewZone.removeChild(imgProd);
                            previewZone.appendChild(filePreview);
                          }
                          reader.readAsDataURL(input.files[0]);
                        }
                      }

                      let fileUpload = document.getElementById('subirArchivo');
                      fileUpload.onchange = function(e) {
                        readFile(e.target);
                      }
                    </script>
                  </div>
                </div>
              </div>

              <!--Accordion opcion 2 Mostrar Productos-->
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerMostrarProducts">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMostrarProducts" aria-expanded="false" aria-controls="collapseMostrarProducts" id="btnAccordionMostrarProducts" onclick="recuperarProducts_Administrar()"><strong>Mostrar Productos</strong></button>
                </h2>
                <div id="collapseMostrarProducts" class="accordion-collapse collapse" aria-labelledby="headerMostrarProducts" data-bs-parent="#accordionProducts">
                  <div class="accordion-body">
                    <div class="table-responsive">
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Codigo</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Categoria</th>
                            <th scope="col"></th>

                          </tr>
                        </thead>
                        <tbody id="cuerpoTablaMostrarProducts">
                          <tr>
                            <th scope="row">1</th>
                            <td>Talleres Metalurgicos Chile S.A.</td>
                            <td>93.160.000-1</td>
                            <td>Correa Errazuriz</td>
                            <td>Aguirre Cerda</td>
                            <td>contacto@talleresmetalurgicos.cl</td>
                            <td>+56912341234</td>
                          </tr>
                          <tr>
                            <th scope="row">2</th>
                            <td>Talleres Metalurgicos Chile S.A.</td>
                            <td>93.160.000-1</td>
                            <td>Correa Errazuriz</td>
                            <td>Aguirre Cerda</td>
                            <td>contacto@talleresmetalurgicos.cl</td>
                            <td>+56912341234</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

          <!--Accordion Cotizaciones-->
          <div class="tab-pane fade" id="cotizacionesConte" role="tabpanel" aria-labelledby="tabCotizaciones">
            <div class="accordion" id="accordionCotizacion">
              <!--Accordion opcion 1 Mostrar Cotizaciones-->
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerMostrarCotizacion">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMostrarCotizacion" aria-expanded="true" aria-controls="collapseMostrarCotizacion" id="btnAccordionMostrarCotizacion"><strong>Mostrar
                      Cotizaciones</strong></button>
                </h2>
                <div id="collapseMostrarCotizacion" class="accordion-collapse collapse show" aria-labelledby="headerMostrarCotizacion" data-bs-parent="#accordionCotizacion">
                  <div class="accordion-body">
                    <div class="table-responsive">
                      <table class="table table-striped placeholder-glow">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">ID</th>
                            <th scope="col">Fecha</th>
                            <th scope="col">RUT</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Email</th>
                            <th scope="col"></th>
                          </tr>
                        </thead>
                        <tbody id="cuerpoTablaMostrarCotizacion">
                          <tr>
                            <th scope="row" class="placeholder">1</th>
                            <td class="placeholder">Cargando su TABLA</td>
                            <td class="placeholder">Cargando su TABLA</td>
                            <td class="placeholder">Cargando su TABLA</td>
                            <td class="placeholder">Cargando su TABLA</td>
                            <td class="placeholder">Cargando su TABLA</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <!--Accordion opcion 2 Responder Cotizacion-->
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerResponderCotizacion">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseResponderCotizacion" aria-expanded="false" aria-controls="collapseResponderCotizacion" id="btnAccordionResponderCotizacion"><strong>Responder
                      Cotizacion</strong></button>
                </h2>
                <div id="collapseResponderCotizacion" class="accordion-collapse collapse" aria-labelledby="headerMostrarCotizacion" data-bs-parent="#accordionCotizacion">
                  <div class="accordion-body" id="cotizacion">
                    <div class="row card">
                      <div class="card-body">
                        <div class="row">
                          <img src="imgs/tigor header cotiz.jpg" alt="">
                        </div>
                        <hr>
                        <div class="row">
                          <div class="col-12 col-md-6 mb-1">
                            <div class="input-group">
                              <span class="input-group-text col-3" id="basic-addon1">Nombre</span>
                              <input type="text" class="form-control" placeholder="Username" value="Nombre" aria-label="Username" id="nombreCotizacion" aria-describedby="basic-addon1" disabled>
                            </div>
                          </div>
                          <div class="col-12 col-md-6 mb-1">
                            <div class="input-group">
                              <span class="input-group-text col-3" id="basic-addon2">ID</span>
                              <input type="text" class="form-control" placeholder="Username" value="N° Cotización" aria-label="Username" id="numeroCotizacion" aria-describedby="basic-addon2" disabled>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-12 col-md-6 mb-1">
                            <div class="input-group">
                              <span class="input-group-text col-3" id="basic-addon3">RUT</span>
                              <input type="text" class="form-control" placeholder="Username" aria-label="Username" id="rutCotizacion" aria-describedby="basic-addon3" disabled>
                            </div>
                          </div>
                          <div class="col-12 col-md-6 mb-1">
                            <div class="input-group">
                              <span class="input-group-text col-3" id="basic-addon4">Fecha</span>
                              <input type="text" class="form-control" placeholder="Username" aria-label="Username" id="fechaCotizacion" aria-describedby="basic-addon4" disabled>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-12 col-md-6 mb-1">
                            <div class="input-group">
                              <span class="input-group-text col-3" id="basic-addon5">Dirección</span>
                              <input type="text" class="form-control" placeholder="Username" aria-label="Username" id="direccionCotizacion" aria-describedby="basic-addon5" disabled>
                            </div>
                          </div>
                          <div class="col-12 col-md-6 mb-1">
                            <div class="input-group">
                              <span class="input-group-text col-3" id="basic-addon6">Comuna</span>
                              <input type="text" class="form-control" placeholder="Username" aria-label="Username" id="comunaCotizacion" aria-describedby="basic-addon6" disabled>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-12 col-md-6 mb-1">
                            <div class="input-group">
                              <span class="input-group-text col-3" id="basic-addon7">Email</span>
                              <input type="text" class="form-control" placeholder="Username" aria-label="Username" id="emailCotizacion" aria-describedby="basic-addon7" readonly>
                            </div>
                          </div>
                          <div class="col-12 col-md-6 mb-1">
                            <div class="input-group">
                              <span class="input-group-text col-3" id="basic-addon8">Teléfono</span>
                              <input type="text" class="form-control" placeholder="Username" aria-label="Username" id="telefonoCotizacion" aria-describedby="basic-addon8" readonly>
                            </div>
                          </div>
                        </div>
                        <hr>
                        <div class="row">
                          <div class="col-12">
                            <table class="table">
                              <thead>
                                <tr>
                                  <th>Id</th>
                                  <th>Codigo</th>
                                  <th>Nombre</th>
                                  <th>Valor Unitario</th>
                                  <th>Unidades</th>
                                  <th>Total</th>
                                </tr>
                              </thead>
                              <tbody id="tBodyProdsCotizacion"></tbody>
                            </table>
                            <div class="d-flex flex-row-reverse">
                              <div class="col-12 col-md-5 mb-3">
                                <div class="input-group">
                                  <span class="input-group-text col-4" id="basic-addon1">Valor Neto</span>
                                  <input type="text" class="form-control" placeholder="Username" aria-label="Username" value="0" id="valorNetoCotizacion" aria-describedby="basic-addon1" readonly>
                                </div>
                              </div>
                            </div>
                            <div class="d-flex flex-row-reverse">
                              <div class="col-12 col-md-5 mb-3">
                                <div class="input-group">
                                  <span class="input-group-text col-4" id="basic-addon1">IVA 19%</span>
                                  <input type="text" class="form-control" placeholder="Username" aria-label="Username" value="0" id="ivaNetoCotizacion" aria-describedby="basic-addon1" readonly>
                                </div>
                              </div>
                            </div>
                            <div class="d-flex flex-row-reverse">
                              <div class="col-12 col-md-5 mb-3">
                                <div class="input-group">
                                  <span class="input-group-text col-4" id="basic-addon1">TOTAL</span>
                                  <input type="text" class="form-control fw-bold" placeholder="Username" aria-label="Username" value="0" id="totalCotizacion" aria-describedby="basic-addon1" readonly>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <button id="btnCrearPDF" type="button" class="btn btn-primary mt-3" onclick="goPDF()">Crear PDF</button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!--Accordion Contacto-->
          <div class="tab-pane fade" id="contactoConte" role="tabpanel" aria-labelledby="tabContacto">
            <div class="accordion" id="accordionContacto">
              <!--Accordion opcion 1 Mostrar Contacto-->
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerMostrarContacto">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMostrarContacto" aria-expanded="true" aria-controls="collapseMostrarContacto" id="btnAccordionMostrarContacto"><strong>Mostrar Contactos</strong></button>
                </h2>
                <div id="collapseMostrarContacto" class="accordion-collapse collapse show" aria-labelledby="headerMostrarContacto" data-bs-parent="#accordionContacto">
                  <div class="accordion-body">
                    <div class="table-responsive">
                      <table class="table table-striped placeholder-glow">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">ID</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Email</th>
                            <th scope="col">Teléfono</th>
                            <th scope="col"></th>
                          </tr>
                        </thead>
                        <tbody id="cuerpoTablaMostrarContact">
                          <tr>
                            <th scope="row" class="placeholder">1</th>
                            <td class="placeholder">Cargando su TABLA</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <!--Accordion opcion 2 Mensaje Contacto-->
              <div class="accordion-item">
                <h2 class="accordion-header" id="headerMensajeContacto">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMensajeContacto" aria-expanded="false" aria-controls="collapseMensajeContacto" id="btnAccordionMensajeContacto"><strong>Mensaje Contacto</strong></button>
                </h2>
                <div id="collapseMensajeContacto" class="accordion-collapse collapse" aria-labelledby="headerMensajeContacto" data-bs-parent="#accordionContacto">
                  <div class="accordion-body">
                    <div class="card">
                      <div class="card-header">
                        <div class="row">
                          <div id="mailMsgContact" class="col-5">Correo: </div>
                          <div id="phoneMsgContact" class="col-5">Teléfono: </div>
                          <div id="idMsgContact" class="col-2 text-end">ID:</div>
                        </div>
                      </div>
                      <div class="card-body">
                        <div class="card">
                          <div id="nameMsgContact" class="card-header">
                            Mensaje de
                          </div>
                          <div id="messageMsgContact" class="card-body">

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--FOOTER-->
  <footer class="footer bg-secondary mt-auto">
    <div class="container">
      <footer class="row mt-5 mb-2 pt-3 me-3 border-top border-dark">
        <div class="col-2 d-flex align-items-center justify-content-center">
          <a href="index.html" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1">
            <img src="imgs/logoTigor.svg" alt="" class="" style="width: 100px; height: auto;">
          </a>
        </div>
        <div class="col-5 d-flex flex-column align-items-center justify-content-center">
          <div class="fs-6"><strong>COMERCIALIZADORA Y DISTRIBUIDORA TORRES IGOR SPA</strong></div>
          <div class="text-muted">DESDE 2019 CON USTED</div>
        </div>
        <div class="col-2"></div>
        <div class="col-3">
          <h5>CONTACTO</h5>
          <ul class="nav flex-column justify-content-end">
            <li class="nav-item mb-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 16 16">
                <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z" />
              </svg>
              <strong>: +569 7352 4463</strong>
            </li>
            <li class="nav-item mb-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
                <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2Zm13 2.383-4.708 2.825L15 11.105V5.383Zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741ZM1 11.105l4.708-2.897L1 5.383v5.722Z" />
              </svg> <strong>: ventas@tigor.cl</strong></li>
          </ul>
        </div>
      </footer>
    </div>
  </footer>
</body>

</html>