function productsFiltro(filtro){
    //location.href = "productos.html";
    console.log("enter product Filtro");
    recuperarProducts_Producto(filtro);
}